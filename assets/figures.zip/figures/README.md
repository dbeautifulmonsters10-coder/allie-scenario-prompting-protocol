# figures/

This directory contains figure files for `ASPP_Preprint_v1_0.tex`.

## Files

- `figure1_aspp_decision_constriction_model.svg`  
  Visualizes the ASPP decision-constriction model.

- `figure2_scenario_framework.svg`  
  Visualizes the S.C.E.N.A.R.I.O. framework stages.

## Recommended LaTeX Usage

To include SVG files directly, compile with an SVG-compatible LaTeX workflow or convert the SVG files to PDF/PNG before submission.

Example:

```latex
\usepackage{graphicx}

\begin{figure}[h]
\centering
\includegraphics[width=0.95\textwidth]{figures/figure1_aspp_decision_constriction_model.pdf}
\caption{ASPP Decision-Constriction Model}
\end{figure}
```

## Attribution

Figures created for The Allie Scenario Prompting Protocol (ASPP), credited to Darren L. Allie, Director of AI Workflow Optimization and AI Business Improvement, Azure & Verdant Vistas, LLC.

DOI: 10.5281/zenodo.20596641
